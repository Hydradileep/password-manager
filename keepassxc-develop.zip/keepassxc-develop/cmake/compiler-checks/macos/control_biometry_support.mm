#include <Security/Security.h>

int main() {
   return static_cast<int>(kSecAccessControlBiometryCurrentSet);
}